﻿Hero artur = new Hero("Artur", 100);
Dragon sapfiron = new Dragon("Sapfiron", 500);

Console.WriteLine(artur.Name);
Console.WriteLine(artur.HP);
Console.WriteLine(sapfiron.Name);
Console.WriteLine(sapfiron.HP);

Weapon e = new Weapon();
e.Name = "Excalibur";
e.Damage = e.Excalibur();

artur.Inventory.Add(e);

double ex = artur.Inventory.Where(x => x.Name == "Excalibur").First().Damage;

artur.Bite(sapfiron);   

sapfiron.Incinerate(artur);

artur.Swordstrike(sapfiron);